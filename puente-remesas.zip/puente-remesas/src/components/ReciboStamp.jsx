import React, { useEffect, useRef, useState } from "react";
import { COLORS } from "../theme";

export default function ReciboStamp({ monto, destino, live = false }) {
  const [elapsed, setElapsed] = useState(0);
  const [status, setStatus] = useState(live ? "en camino" : "llegó");
  const ticket = useRef("MX-" + Math.floor(100000 + Math.random() * 900000)).current;

  useEffect(() => {
    if (!live) return;
    setElapsed(0);
    setStatus("en camino");
    const start = Date.now();
    const iv = setInterval(() => {
      const s = (Date.now() - start) / 1000;
      setElapsed(s);
      if (s >= 3) {
        setStatus("llegó");
        clearInterval(iv);
      }
    }, 100);
    return () => clearInterval(iv);
  }, [live, monto]);

  return (
    <div
      className="relative w-full max-w-sm mx-auto font-mono"
      style={{
        background: "#fff",
        border: `1.5px solid ${COLORS.ink}`,
        borderRadius: 4,
        boxShadow: "6px 6px 0px rgba(28,27,26,0.08)",
      }}
    >
      <div className="flex items-center justify-between px-5 pt-4">
        <span className="text-[10px] uppercase tracking-widest text-ink-soft">Recibo digital</span>
        <span className="text-[10px] uppercase tracking-widest text-ink-soft">{ticket}</span>
      </div>

      <div className="px-5 pt-3 pb-4">
        <div className="text-3xl font-semibold text-ink">
          ${Number(monto || 0).toLocaleString("es-MX", { minimumFractionDigits: 2 })}
        </div>
        <div className="text-xs mt-1 text-ink-soft">para {destino || "familia en México"}</div>
      </div>

      <div className="mx-5" style={{ borderTop: `1.5px dashed ${COLORS.line}` }} />

      <div className="flex items-center justify-between px-5 py-3">
        <div className="text-[11px] text-ink-soft">
          {live ? `${elapsed.toFixed(1)}s transcurridos` : "liquidado en 4.2s"}
        </div>
        <div
          className="text-[11px] font-semibold px-2 py-1 rounded-sm uppercase tracking-wide transition-all"
          style={{
            color: status === "llegó" ? "#fff" : COLORS.ink,
            background: status === "llegó" ? COLORS.verde : COLORS.paperDim,
            border: status === "llegó" ? "none" : `1px solid ${COLORS.line}`,
          }}
        >
          {status === "llegó" ? "✓ Llegó" : "En camino"}
        </div>
      </div>

      <div
        className="absolute -left-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full"
        style={{ background: COLORS.paper, border: `1.5px solid ${COLORS.ink}` }}
      />
      <div
        className="absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full"
        style={{ background: COLORS.paper, border: `1.5px solid ${COLORS.ink}` }}
      />
    </div>
  );
}
