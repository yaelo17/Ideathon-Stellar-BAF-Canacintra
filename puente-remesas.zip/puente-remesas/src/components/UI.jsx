import React from "react";
import { NavLink } from "react-router-dom";
import { COLORS } from "../theme";

export function Perforation() {
  return <div className="w-full my-8 sm:my-12" style={{ borderTop: `2px dashed ${COLORS.line}` }} />;
}

export function Eyebrow({ children, color = COLORS.rosa }) {
  return (
    <div
      className="inline-flex items-center gap-2 text-xs tracking-widest uppercase mb-4 font-mono"
      style={{ color, letterSpacing: "0.12em" }}
    >
      <span style={{ width: 16, height: 1, background: color, display: "inline-block" }} />
      {children}
    </div>
  );
}

export function NavBar() {
  const items = [
    { to: "/", label: "Inicio" },
    { to: "/simulador", label: "Simulador" },
    { to: "/dashboard", label: "Dashboard" },
  ];
  return (
    <div
      className="sticky top-0 z-20 w-full flex items-center justify-between px-6 sm:px-10 py-4"
      style={{ background: COLORS.paper, borderBottom: `1.5px solid ${COLORS.ink}` }}
    >
      <div className="text-lg font-semibold flex items-center gap-2 font-display text-ink">
        <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ background: COLORS.rosa }} />
        Puente
      </div>
      <div className="flex items-center gap-1 sm:gap-2 font-sans">
        {items.map((it) => (
          <NavLink
            key={it.to}
            to={it.to}
            end={it.to === "/"}
            className="px-3 sm:px-4 py-1.5 text-xs sm:text-sm rounded-sm transition-colors font-medium"
            style={({ isActive }) => ({
              color: isActive ? "#fff" : COLORS.ink,
              background: isActive ? COLORS.ink : "transparent",
            })}
          >
            {it.label}
          </NavLink>
        ))}
      </div>
    </div>
  );
}

export function Footer() {
  return (
    <>
      <div className="max-w-5xl mx-auto px-6 sm:px-10">
        <Perforation />
      </div>
      <footer className="max-w-5xl mx-auto px-6 sm:px-10 pb-12 flex items-center justify-between font-mono text-xs text-ink-soft">
        <span>© 2026 Puente — demo, no es un producto financiero real</span>
        <span>EE.UU. ⇄ México</span>
      </footer>
    </>
  );
}
