import React from "react";
import { Routes, Route } from "react-router-dom";
import { NavBar, Footer } from "./components/UI";
import Landing from "./pages/Landing";
import Simulador from "./pages/Simulador";
import Dashboard from "./pages/Dashboard";

export default function App() {
  return (
    <div className="bg-paper min-h-full">
      <NavBar />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/simulador" element={<Simulador />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
      <Footer />
    </div>
  );
}
