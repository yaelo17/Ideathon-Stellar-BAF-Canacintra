// Tokens de diseño — concepto "recibo digital"
export const COLORS = {
  paper: "#FAF6EC",
  paperDim: "#F1EBDC",
  ink: "#1C1B1A",
  inkSoft: "#5B564C",
  rosa: "#D6006F",
  verde: "#0B6E4F",
  marigold: "#B8860B",
  line: "#D8D0BE",
};

// Supuestos del simulador — reemplazar por datos reales / API de tipo de cambio
export const FEE_TRADICIONAL = 0.065; // 6.5%
export const FEE_PLATAFORMA = 0.01; // 1%
export const TIPO_CAMBIO = 18.5; // MXN por USD (mock)
