import React from "react";
import { Link } from "react-router-dom";
import { COLORS } from "../theme";
import { Eyebrow, Perforation } from "../components/UI";
import ReciboStamp from "../components/ReciboStamp";

export default function Landing() {
  return (
    <div>
      <section className="px-6 sm:px-10 pt-14 sm:pt-20 pb-6 max-w-5xl mx-auto">
        <Eyebrow>Envíos EE.UU. → México</Eyebrow>
        <h1 className="text-4xl sm:text-6xl leading-[1.05] font-semibold max-w-2xl font-display text-ink">
          El recibo que <span style={{ fontStyle: "italic", color: COLORS.rosa }}>sí</span> llega
          <br />
          en segundos.
        </h1>
        <p className="mt-5 text-base sm:text-lg max-w-lg font-sans text-ink-soft">
          Cambia el 6% de comisión y los 2-3 días de espera por rieles blockchain: menos de 1% de
          costo y liquidación casi instantánea, de tu banco en EE.UU. a la mano de tu familia en
          México.
        </p>
        <div className="mt-8 flex flex-wrap items-center gap-4">
          <Link
            to="/simulador"
            className="px-6 py-3 text-sm font-semibold rounded-sm font-sans"
            style={{ background: COLORS.rosa, color: "#fff" }}
          >
            Simular un envío →
          </Link>
          <Link
            to="/dashboard"
            className="px-6 py-3 text-sm font-medium rounded-sm font-sans text-ink"
            style={{ border: `1.5px solid ${COLORS.ink}` }}
          >
            Ver mi dashboard
          </Link>
        </div>
      </section>

      <section className="px-6 sm:px-10 pt-10">
        <ReciboStamp monto={2500} destino="Mamá — Guanajuato" />
      </section>

      <div className="max-w-5xl mx-auto px-6 sm:px-10">
        <Perforation />
      </div>

      <section className="max-w-5xl mx-auto px-6 sm:px-10 pb-16">
        <Eyebrow color={COLORS.verde}>Por qué duele hoy</Eyebrow>
        <div className="grid sm:grid-cols-2 gap-6 mt-4">
          <div className="p-6 rounded-sm bg-white" style={{ border: `1.5px solid ${COLORS.line}` }}>
            <div className="text-xs uppercase tracking-widest mb-2 font-mono text-ink-soft">
              Remesadora tradicional
            </div>
            <div className="text-4xl font-semibold font-display text-ink">5–8%</div>
            <p className="text-sm mt-2 font-sans text-ink-soft">
              de comisión, más margen oculto en el tipo de cambio. Hasta 3 días para liquidar.
            </p>
          </div>
          <div className="p-6 rounded-sm" style={{ background: COLORS.ink }}>
            <div className="text-xs uppercase tracking-widest mb-2 font-mono" style={{ color: "#D8D0BE" }}>
              Puente (blockchain)
            </div>
            <div className="text-4xl font-semibold font-display text-white">~1%</div>
            <p className="text-sm mt-2 font-sans" style={{ color: "#C9C2B4" }}>
              tipo de cambio transparente. Liquidación en segundos, disponible las 24 horas.
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-5xl mx-auto px-6 sm:px-10">
        <Perforation />
      </div>

      <section className="max-w-5xl mx-auto px-6 sm:px-10 pb-20">
        <Eyebrow>Cómo funciona</Eyebrow>
        <div className="grid sm:grid-cols-3 gap-4 mt-4">
          {[
            { code: "01A", title: "Envía", desc: "Depositas USD desde tu cuenta o tarjeta en la app." },
            { code: "02A", title: "Convierte", desc: "Se convierte a stablecoin y viaja por la red en segundos." },
            { code: "03A", title: "Llega", desc: "Tu familia retira en pesos en un corresponsal o su cuenta." },
          ].map((s) => (
            <div key={s.code} className="p-5" style={{ borderLeft: `2px solid ${COLORS.rosa}` }}>
              <div className="text-xs mb-2 font-mono" style={{ color: COLORS.rosa }}>
                {s.code}
              </div>
              <div className="text-lg font-semibold font-display text-ink">{s.title}</div>
              <p className="text-sm mt-1 font-sans text-ink-soft">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
