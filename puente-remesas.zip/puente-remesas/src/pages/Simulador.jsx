import React, { useState } from "react";
import { COLORS, FEE_TRADICIONAL, FEE_PLATAFORMA, TIPO_CAMBIO } from "../theme";
import { Eyebrow } from "../components/UI";
import ReciboStamp from "../components/ReciboStamp";

export default function Simulador() {
  const [monto, setMonto] = useState(200);
  const [nombre, setNombre] = useState("");
  const [enviado, setEnviado] = useState(false);

  const comisionTrad = monto * FEE_TRADICIONAL;
  const comisionPlat = monto * FEE_PLATAFORMA;
  const recibeTrad = (monto - comisionTrad) * TIPO_CAMBIO;
  const recibePlat = (monto - comisionPlat) * TIPO_CAMBIO;
  const ahorro = comisionTrad - comisionPlat;

  return (
    <div className="max-w-5xl mx-auto px-6 sm:px-10 py-12 sm:py-16">
      <Eyebrow>Simulador</Eyebrow>
      <h2 className="text-3xl sm:text-4xl font-semibold mb-8 font-display text-ink">
        ¿Cuánto llega a México?
      </h2>

      <div className="grid lg:grid-cols-2 gap-10">
        <div>
          <label className="text-xs uppercase tracking-widest font-mono text-ink-soft">
            Monto a enviar (USD)
          </label>
          <div className="flex items-center mt-2 mb-1">
            <span className="text-3xl mr-2 font-display text-ink">$</span>
            <input
              type="number"
              min={10}
              max={5000}
              value={monto}
              onChange={(e) => setMonto(Math.max(0, Number(e.target.value)))}
              className="text-3xl font-semibold bg-transparent outline-none w-40 font-display text-ink"
              style={{ borderBottom: `2px solid ${COLORS.ink}` }}
            />
          </div>
          <input
            type="range"
            min={10}
            max={2000}
            value={monto}
            onChange={(e) => setMonto(Number(e.target.value))}
            className="w-full mt-4"
            style={{ accentColor: COLORS.rosa }}
          />

          <label className="text-xs uppercase tracking-widest mt-8 block font-mono text-ink-soft">
            ¿Para quién es?
          </label>
          <input
            type="text"
            placeholder="Nombre de quien recibe"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            className="w-full mt-2 px-3 py-2 text-sm outline-none rounded-sm font-sans text-ink"
            style={{ border: `1.5px solid ${COLORS.line}` }}
          />

          <button
            onClick={() => setEnviado(true)}
            className="mt-8 w-full sm:w-auto px-6 py-3 text-sm font-semibold rounded-sm font-sans"
            style={{ background: COLORS.rosa, color: "#fff" }}
          >
            Simular envío →
          </button>

          <div className="mt-10 space-y-3 font-sans">
            <div
              className="flex items-center justify-between text-sm pb-2"
              style={{ borderBottom: `1px solid ${COLORS.line}` }}
            >
              <span className="text-ink-soft">Remesadora tradicional (6.5%)</span>
              <span className="font-mono text-ink">
                ${recibeTrad.toLocaleString("es-MX", { maximumFractionDigits: 0 })} MXN
              </span>
            </div>
            <div
              className="flex items-center justify-between text-sm pb-2"
              style={{ borderBottom: `1px solid ${COLORS.line}` }}
            >
              <span className="font-semibold" style={{ color: COLORS.verde }}>
                Con Puente (1%)
              </span>
              <span className="font-mono font-semibold" style={{ color: COLORS.verde }}>
                ${recibePlat.toLocaleString("es-MX", { maximumFractionDigits: 0 })} MXN
              </span>
            </div>
            <div className="flex items-center justify-between text-sm pt-1">
              <span className="text-ink-soft">Ahorro en esta comisión</span>
              <span className="font-mono font-semibold" style={{ color: COLORS.marigold }}>
                ${ahorro.toLocaleString("es-MX", { minimumFractionDigits: 2 })} USD
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-start justify-center pt-4">
          <ReciboStamp key={enviado ? Date.now() : "static"} monto={monto} destino={nombre} live={enviado} />
        </div>
      </div>
    </div>
  );
}
