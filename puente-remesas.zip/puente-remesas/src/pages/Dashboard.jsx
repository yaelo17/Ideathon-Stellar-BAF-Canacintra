import React from "react";
import { COLORS } from "../theme";
import { Eyebrow } from "../components/UI";

const HISTORIAL = [
  { id: "MX-482910", fecha: "27 ago, 9:14 am", monto: 300, estado: "Recibido" },
  { id: "MX-482774", fecha: "20 ago, 8:02 am", monto: 150, estado: "Recibido" },
  { id: "MX-482601", fecha: "13 ago, 7:45 am", monto: 500, estado: "Recibido" },
  { id: "MX-482355", fecha: "6 ago, 9:30 am", monto: 200, estado: "Recibido" },
];

export default function Dashboard() {
  const saldo = 128.4;
  const totalMes = HISTORIAL.reduce((a, b) => a + b.monto, 0);

  return (
    <div className="max-w-5xl mx-auto px-6 sm:px-10 py-12 sm:py-16">
      <Eyebrow>Tu cuenta</Eyebrow>
      <h2 className="text-3xl sm:text-4xl font-semibold mb-8 font-display text-ink">
        Hola, Marisol
      </h2>

      <div className="grid sm:grid-cols-3 gap-4 mb-10">
        <div className="p-5 rounded-sm" style={{ background: COLORS.ink }}>
          <div className="text-xs uppercase tracking-widest font-mono" style={{ color: "#C9C2B4" }}>
            Saldo disponible
          </div>
          <div className="text-2xl font-semibold mt-2 font-display text-white">
            ${saldo.toFixed(2)} USD
          </div>
        </div>
        <div className="p-5 rounded-sm" style={{ border: `1.5px solid ${COLORS.line}` }}>
          <div className="text-xs uppercase tracking-widest font-mono text-ink-soft">
            Enviado este mes
          </div>
          <div className="text-2xl font-semibold mt-2 font-display text-ink">
            ${totalMes.toLocaleString("es-MX")} USD
          </div>
        </div>
        <div className="p-5 rounded-sm" style={{ border: `1.5px solid ${COLORS.line}` }}>
          <div className="text-xs uppercase tracking-widest font-mono text-ink-soft">
            Comisión promedio
          </div>
          <div className="text-2xl font-semibold mt-2 font-display" style={{ color: COLORS.verde }}>
            0.98%
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-3">
        <div className="text-xs uppercase tracking-widest font-mono text-ink-soft">
          Historial de envíos
        </div>
        <button
          className="text-xs font-semibold px-4 py-2 rounded-sm font-sans"
          style={{ background: COLORS.rosa, color: "#fff" }}
        >
          + Nueva remesa
        </button>
      </div>

      <div style={{ border: `1.5px solid ${COLORS.ink}`, borderRadius: 4, overflow: "hidden" }}>
        {HISTORIAL.map((tx, i) => (
          <div
            key={tx.id}
            className="flex items-center justify-between px-4 sm:px-5 py-3.5"
            style={{
              background: i % 2 === 0 ? "#fff" : COLORS.paperDim,
              borderTop: i === 0 ? "none" : `1px dashed ${COLORS.line}`,
            }}
          >
            <div className="flex items-center gap-3">
              <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: COLORS.verde }} />
              <div>
                <div className="text-sm font-medium font-sans text-ink">${tx.monto} USD</div>
                <div className="text-xs font-mono text-ink-soft">
                  {tx.id} · {tx.fecha}
                </div>
              </div>
            </div>
            <span
              className="text-xs font-semibold px-2 py-1 rounded-sm font-sans"
              style={{ color: "#fff", background: COLORS.verde }}
            >
              {tx.estado}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
