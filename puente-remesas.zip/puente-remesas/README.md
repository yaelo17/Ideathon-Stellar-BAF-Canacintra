# Puente — Remesas EE.UU. → México con Blockchain

Interfaz de prueba (frontend) para explorar un modelo de negocio de remesas
que usa rieles blockchain (stablecoins) para bajar comisiones de 5-8% a ~1%
y pasar de días a segundos en la liquidación.

Este repo es solo el **prototipo visual/UX** — no incluye backend, custodia
de fondos, integración real con blockchain ni cumplimiento regulatorio.

## Vistas incluidas

- **Inicio** (`/`) — propuesta de valor, comparación de costos, cómo funciona.
- **Simulador** (`/simulador`) — calculadora interactiva: comisión tradicional
  vs. plataforma, con un recibo digital animado que simula la liquidación.
- **Dashboard** (`/dashboard`) — vista de usuario con saldo, historial de
  envíos y acceso a nueva remesa (datos de ejemplo, no reales).

## Stack

- [Vite](https://vitejs.dev/) + [React](https://react.dev/)
- [React Router](https://reactrouter.com/) para las 3 vistas
- [Tailwind CSS](https://tailwindcss.com/) con tokens de diseño propios en
  `tailwind.config.js` y `src/theme.js`

## Cómo correrlo localmente

```bash
npm install
npm run dev
```

Abre `http://localhost:5173`.

Para generar el build de producción:

```bash
npm run build
npm run preview
```

## Sistema de diseño

Concepto: **"el recibo que sí llega"** — se reinterpreta el recibo de papel
de las remesadoras tradicionales como un recibo digital con sello animado,
para hacer tangible la promesa de velocidad.

- **Color:** papel `#FAF6EC`, tinta `#1C1B1A`, rosa mexicano `#D6006F`,
  verde `#0B6E4F`, marigold `#B8860B`.
- **Tipografía:** Fraunces (títulos), IBM Plex Mono (montos/tickets),
  Work Sans (UI/cuerpo).

## Próximos pasos sugeridos

- [ ] Conectar el simulador a un tipo de cambio real (API).
- [ ] Definir el proveedor de rieles blockchain / stablecoin (Stellar, Polygon, Solana).
- [ ] Diseñar el flujo de KYC/onboarding (no incluido en esta versión).
- [ ] Backend + base de datos para el dashboard real.
