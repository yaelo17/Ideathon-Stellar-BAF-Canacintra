/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#FAF6EC",
        "paper-dim": "#F1EBDC",
        ink: "#1C1B1A",
        "ink-soft": "#5B564C",
        rosa: "#D6006F",
        verde: "#0B6E4F",
        marigold: "#B8860B",
        line: "#D8D0BE",
      },
      fontFamily: {
        display: ["Fraunces", "serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
        sans: ["'Work Sans'", "sans-serif"],
      },
    },
  },
  plugins: [],
};
